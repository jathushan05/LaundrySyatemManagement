package com.laundry.service;

import com.laundry.dao.ReportDAO;
import com.laundry.model.DashboardStats;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Map;

public class ReportService {
    private final ReportDAO reportDAO = new ReportDAO();
    public DashboardStats dashboard() throws SQLException { return reportDAO.loadDashboard(); }
    public Map<String, Long> popularServices(String from, String to) throws SQLException { return reportDAO.popularServices(from, to); }
    public Map<String, BigDecimal> inventoryUsage(String from, String to) throws SQLException { return reportDAO.inventoryUsage(from, to); }
    public Map<String, Long> deliveryPerformance(String from, String to) throws SQLException { return reportDAO.deliveryPerformance(from, to); }
}
