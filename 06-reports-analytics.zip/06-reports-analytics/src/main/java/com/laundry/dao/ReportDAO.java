package com.laundry.dao;

import com.laundry.model.DashboardStats;
import com.laundry.util.DatabaseUtil;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.Map;

public class ReportDAO {
    public DashboardStats loadDashboard() throws SQLException {
        DashboardStats stats = new DashboardStats();
        try (Connection connection = DatabaseUtil.getConnection()) {
            stats.setTotalCustomers(longValue(connection, "SELECT COUNT(*) FROM customers WHERE account_status='ACTIVE'"));
            stats.setTotalOrders(longValue(connection, "SELECT COUNT(*) FROM laundry_orders"));
            stats.setPendingOrders(longValue(connection, "SELECT COUNT(*) FROM laundry_orders WHERE status IN ('RECEIVED','WASHING','PROCESSING','READY')"));
            stats.setCompletedOrders(longValue(connection, "SELECT COUNT(*) FROM laundry_orders WHERE status='COMPLETED'"));
            stats.setDeliveredOrders(longValue(connection, "SELECT COUNT(*) FROM laundry_orders WHERE status='DELIVERED'"));
            stats.setTotalRevenue(decimalValue(connection, "SELECT COALESCE(SUM(total_amount),0) FROM laundry_orders WHERE status IN ('COMPLETED','DELIVERED')"));
            stats.setMonthlyRevenue(decimalValue(connection, "SELECT COALESCE(SUM(total_amount),0) FROM laundry_orders WHERE status IN ('COMPLETED','DELIVERED') AND YEAR(received_at)=YEAR(CURRENT_TIMESTAMP) AND MONTH(received_at)=MONTH(CURRENT_TIMESTAMP)"));
            stats.setLowStockItems(longValue(connection, "SELECT COUNT(*) FROM inventory_items WHERE status='ACTIVE' AND quantity<=reorder_level"));
            stats.setScheduledDeliveries(longValue(connection, "SELECT COUNT(*) FROM pickup_delivery WHERE status IN ('REQUESTED','SCHEDULED','PICKED_UP','PROCESSING','OUT_FOR_DELIVERY')"));
            stats.setAverageRating(doubleValue(connection, "SELECT COALESCE(AVG(CAST(rating AS decimal(5,2))),0) FROM feedback_reviews WHERE moderation_status='APPROVED'"));
            stats.setMonthlyRevenueChart(monthlyRevenue(connection));
            stats.setOrderStatusChart(orderStatuses(connection));
            stats.setRatingChart(ratings(connection));
        }
        return stats;
    }

    public Map<String, Long> popularServices(String from, String to) throws SQLException {
        Map<String, Long> values = new LinkedHashMap<>();
        String sql = "SELECT s.service_name,SUM(oi.quantity) total FROM order_items oi JOIN services s ON s.service_id=oi.service_id " +
                "JOIN laundry_orders o ON o.order_id=oi.order_id WHERE (? IS NULL OR CAST(o.received_at AS date)>=?) AND (? IS NULL OR CAST(o.received_at AS date)<=?) " +
                "AND o.status<>'CANCELLED' GROUP BY s.service_id,s.service_name ORDER BY total DESC";
        try (Connection connection = DatabaseUtil.getConnection(); PreparedStatement statement = connection.prepareStatement(sql)) {
            bindRange(statement, from, to);
            try (ResultSet rs = statement.executeQuery()) { while (rs.next()) values.put(rs.getString(1), rs.getLong(2)); }
        }
        return values;
    }

    public Map<String, BigDecimal> inventoryUsage(String from, String to) throws SQLException {
        Map<String, BigDecimal> values = new LinkedHashMap<>();
        String sql = "SELECT i.item_name,COALESCE(SUM(t.quantity),0) total FROM inventory_transactions t JOIN inventory_items i ON i.inventory_id=t.inventory_id " +
                "WHERE t.transaction_type='USAGE' AND (? IS NULL OR CAST(t.created_at AS date)>=?) AND (? IS NULL OR CAST(t.created_at AS date)<=?) " +
                "GROUP BY i.inventory_id,i.item_name ORDER BY total DESC";
        try (Connection connection = DatabaseUtil.getConnection(); PreparedStatement statement = connection.prepareStatement(sql)) {
            bindRange(statement, from, to);
            try (ResultSet rs = statement.executeQuery()) { while (rs.next()) values.put(rs.getString(1), rs.getBigDecimal(2)); }
        }
        return values;
    }

    public Map<String, Long> deliveryPerformance(String from, String to) throws SQLException {
        Map<String, Long> values = new LinkedHashMap<>();
        String sql = "SELECT performance,COUNT(*) total FROM (SELECT CASE " +
                "WHEN status='DELIVERED' AND delivery_at IS NOT NULL AND updated_at<=delivery_at THEN 'DELIVERED_ON_TIME' " +
                "WHEN status='DELIVERED' THEN 'DELIVERED_LATE' WHEN status='CANCELLED' THEN 'CANCELLED' " +
                "ELSE 'IN_PROGRESS' END performance FROM pickup_delivery " +
                "WHERE (? IS NULL OR CAST(created_at AS date)>=?) AND (? IS NULL OR CAST(created_at AS date)<=?)) AS results GROUP BY performance ORDER BY total DESC";
        try (Connection connection = DatabaseUtil.getConnection(); PreparedStatement statement = connection.prepareStatement(sql)) {
            bindRange(statement, from, to);
            try (ResultSet rs = statement.executeQuery()) { while (rs.next()) values.put(rs.getString(1), rs.getLong(2)); }
        }
        return values;
    }

    private Map<String, BigDecimal> monthlyRevenue(Connection connection) throws SQLException {
        Map<String, BigDecimal> values = new LinkedHashMap<>();
        String sql = "SELECT CONVERT(char(7),received_at,120) revenue_month,COALESCE(SUM(total_amount),0) total FROM laundry_orders " +
                "WHERE status IN ('COMPLETED','DELIVERED') AND received_at>=DATEADD(MONTH,-5,DATEFROMPARTS(YEAR(CURRENT_TIMESTAMP),MONTH(CURRENT_TIMESTAMP),1)) " +
                "GROUP BY CONVERT(char(7),received_at,120) ORDER BY revenue_month";
        try (PreparedStatement statement = connection.prepareStatement(sql); ResultSet rs = statement.executeQuery()) {
            while (rs.next()) values.put(rs.getString(1), rs.getBigDecimal(2));
        }
        return values;
    }

    private Map<String, Long> orderStatuses(Connection connection) throws SQLException {
        Map<String, Long> values = new LinkedHashMap<>();
        String sql = "SELECT status,COUNT(*) total FROM laundry_orders GROUP BY status ORDER BY status";
        try (PreparedStatement statement = connection.prepareStatement(sql); ResultSet rs = statement.executeQuery()) {
            while (rs.next()) values.put(rs.getString(1), rs.getLong(2));
        }
        return values;
    }

    private Map<Integer, Long> ratings(Connection connection) throws SQLException {
        Map<Integer, Long> values = new LinkedHashMap<>();
        for (int i = 1; i <= 5; i++) values.put(i, 0L);
        String sql = "SELECT rating,COUNT(*) total FROM feedback_reviews WHERE moderation_status='APPROVED' GROUP BY rating ORDER BY rating";
        try (PreparedStatement statement = connection.prepareStatement(sql); ResultSet rs = statement.executeQuery()) {
            while (rs.next()) values.put(rs.getInt(1), rs.getLong(2));
        }
        return values;
    }

    private long longValue(Connection connection, String sql) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(sql); ResultSet rs = statement.executeQuery()) {
            rs.next(); return rs.getLong(1);
        }
    }

    private BigDecimal decimalValue(Connection connection, String sql) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(sql); ResultSet rs = statement.executeQuery()) {
            rs.next(); return rs.getBigDecimal(1);
        }
    }

    private double doubleValue(Connection connection, String sql) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(sql); ResultSet rs = statement.executeQuery()) {
            rs.next(); return rs.getDouble(1);
        }
    }

    private void bindRange(PreparedStatement statement, String from, String to) throws SQLException {
        LocalDate start = optionalDate(from);
        LocalDate end = optionalDate(to);
        setNullableDate(statement, 1, start);
        setNullableDate(statement, 2, start);
        setNullableDate(statement, 3, end);
        setNullableDate(statement, 4, end);
    }

    private LocalDate optionalDate(String value) {
        if (value == null || value.isBlank()) return null;
        return LocalDate.parse(value.trim());
    }

    private void setNullableDate(PreparedStatement statement, int index, LocalDate value) throws SQLException {
        if (value == null) statement.setNull(index, java.sql.Types.DATE);
        else statement.setDate(index, java.sql.Date.valueOf(value));
    }
}
