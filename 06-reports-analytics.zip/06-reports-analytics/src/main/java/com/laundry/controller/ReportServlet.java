package com.laundry.controller;

import com.laundry.service.InventoryService;
import com.laundry.service.OrderService;
import com.laundry.service.ReportService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet("/reports")
public class ReportServlet extends BaseServlet {
    private final ReportService reportService = new ReportService();
    private final OrderService orderService = new OrderService();
    private final InventoryService inventoryService = new InventoryService();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            String from = request.getParameter("from");
            String to = request.getParameter("to");
            request.setAttribute("stats", reportService.dashboard());
            request.setAttribute("orders", orderService.list("", request.getParameter("status"), from, to, null));
            request.setAttribute("popularServices", reportService.popularServices(from, to));
            request.setAttribute("inventoryUsage", reportService.inventoryUsage(from, to));
            request.setAttribute("deliveryPerformance", reportService.deliveryPerformance(from, to));
            request.setAttribute("lowStock", inventoryService.list("", "", "ACTIVE", true));
            view(request, response, "report/dashboard");
        } catch (Exception e) {
            failure(request, response, e, "/dashboard");
        }
    }
}
