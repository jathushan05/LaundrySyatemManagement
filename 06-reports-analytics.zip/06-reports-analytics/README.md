# 06 - Reports And Analytics

## Included Files

- `src/main/java/com/laundry/controller/DashboardServlet.java`
- `src/main/java/com/laundry/controller/ReportServlet.java`
- `src/main/java/com/laundry/service/ReportService.java`
- `src/main/java/com/laundry/dao/ReportDAO.java`
- `src/main/java/com/laundry/model/DashboardStats.java`
- `src/main/webapp/WEB-INF/views/report/`
- `src/main/webapp/WEB-INF/views/common/dashboard.jsp`

## Main Features

- Dashboard cards
- Monthly revenue chart
- Order status chart
- Rating distribution
- Popular services report
- Inventory usage report
- Pickup and delivery performance report

## Depends On

- All other components because reports read their data
- `shared-core` for Chart.js layout, login, role handling, and utilities
- `database-sqlserver` reporting queries over all system tables
